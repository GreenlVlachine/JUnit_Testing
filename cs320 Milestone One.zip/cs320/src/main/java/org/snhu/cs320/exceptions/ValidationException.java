package org.snhu.cs320.exceptions;

public class ValidationException extends Exception {

	private static final long serialVersionUID = -44833535862295802L;

	public ValidationException(String message) {
		super(message);
	}
	
}
