package org.snhu.cs320.contact;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	
	@BeforeEach
	void init() {
		ContactService.getInstance().database.clear();
	}

	@Test
	void testGetInstance() {
		assertThat(ContactService.getInstance()).isNotNull();
	}
	
	@Test
	void testAdd() throws Exception {
		Contact contact = new Contact("12345", "First", "Last", "5553334444", "1234 Loblolly Lane");
		assertThat(ContactService.getInstance().add(contact)).isTrue();
		assertThat(ContactService.getInstance().database)
			.containsEntry("12345", contact);
	}
	
	@Test
	void testDelete() throws Exception {
		Contact contact = new Contact("12345", "First", "Last", "5553334444", "1234 Loblolly Lane");
		assertThat(ContactService.getInstance().add(contact)).isTrue();
		assertThat(ContactService.getInstance().delete("12345")).isTrue();
		assertThat(ContactService.getInstance().database).doesNotContainEntry("12345", contact);
	}
	
	@Test
	void testUpdate() throws Exception {
		Contact contact = new Contact("12345", "First", "Last", "5553334444", "1234 Loblolly Lane");
		assertThat(ContactService.getInstance().add(contact)).isTrue();
		
		Contact updated = new Contact("99999", "Steven", "Buscemi", "1112223333", "2024 Grad Street");
		assertThat(ContactService.getInstance().update("12345", updated)).isTrue();
		assertThat(ContactService.getInstance().database)
			.extracting("12345")
			.hasFieldOrPropertyWithValue("firstName", "Steven")
			.hasFieldOrPropertyWithValue("lastName", "Buscemi")
			.hasFieldOrPropertyWithValue("phone", "1112223333")
			.hasFieldOrPropertyWithValue("address", "2024 Grad Street");
			
	}
}
