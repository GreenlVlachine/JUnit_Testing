package org.snhu.cs320.contact;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class ContactTest {

	@Test
	void  testSuccessfulCreation() throws Exception {
		Contact contact = new Contact("1", "First", "Last", "5553334444", "1234 Loblolly Lane");
		assertThat(contact)
			.hasFieldOrPropertyWithValue("id", "1")
			.hasFieldOrPropertyWithValue("firstName", "First")
			.hasFieldOrPropertyWithValue("lastName", "Last")
			.hasFieldOrPropertyWithValue("phone", "5553334444")
			.hasFieldOrPropertyWithValue("address", "1234 Loblolly Lane");
	}
	
	@Test
	void testSuccessfulSetters() throws Exception {
		Contact contact = new Contact("1", "First", "Last", "5553334444", "1234 Loblolly Lane");
		contact.setFirstName("Steven");
		contact.setLastName("Buscemi");
		contact.setPhone("1112223333");
		contact.setAddress("2024 Grad Street");
		assertThat(contact)
			.hasFieldOrPropertyWithValue("firstName", "Steven")
			.hasFieldOrPropertyWithValue("lastName", "Buscemi")
			.hasFieldOrPropertyWithValue("phone", "1112223333")
			.hasFieldOrPropertyWithValue("address", "2024 Grad Street");
	}
	
	@CsvSource({
		"' ',First,Last,5553334444,1234 Loblolly Lane,id must not be blank", // Blank ID
		",First,Last,5553334444,1234 Loblolly Lane,id must not be null", // Null ID
		"12345678901,First,Last,5553334444,1234 Loblolly Lane,id must be at least 1 and no greater than 10 characters in length", // Too Long ID
		"12345,' ',Last,5553334444,1234 Loblolly Lane,firstName must not be blank", // Blank First Name
		"12345,,Last,5553334444,1234 Loblolly Lane,firstName must not be null", // Null First Name
		"12345,FirstFirstF,Last,5553334444,1234 Loblolly Lane,firstName must be at least 1 and no greater than 10 characters in length", // Too Long First Name
		"12345,First,' ',5553334444,1234 Loblolly Lane,lastName must not be blank", // Blank Last Name
		"12345,First,,5553334444,1234 Loblolly Lane,lastName must not be null", // Null Last Name
		"12345,First,LastLastLast,5553334444,1234 Loblolly Lane,lastName must be at least 1 and no greater than 10 characters in length", // Too Long Last Name
		"12345,First,Last,' ',1234 Loblolly Lane,phone must not be blank", // Blank Phone
		"12345,First,Last,,1234 Loblolly Lane,phone must not be null", // Null Phone
		"12345,First,Last,555333444,1234 Loblolly Lane,phone must be at least 10 and no greater than 10 characters in length", // Too Short Phone
		"12345,First,Last,55533344441,1234 Loblolly Lane,phone must be at least 10 and no greater than 10 characters in length", // Too Long Phone
		"12345,First,Last,555333444A,1234 Loblolly Lane,phone must only contain digits", // Phone With Letters
		"12345,First,Last,555333444?,1234 Loblolly Lane,phone must only contain digits", // Phone With Punctuation
		"12345,First,Last,555333 444,1234 Loblolly Lane,phone must only contain digits", // Phone With Spaces
		"12345,First,Last,5553334444,' ',address must not be blank", // Blank Address
		"12345,First,Last,5553334444,,address must not be null", // Null Address
		"12345,First,Last,5553334444,1234 Loblololololololololololololly Lane,address must be at least 1 and no greater than 30 characters in length", // Too Long Address
	})
	@ParameterizedTest
	void testFailedCreation(String id, String firstName, String lastName, String phone, String address, String message) {
		assertThatThrownBy(() -> new Contact(id, firstName, lastName, phone, address))
			.isNotNull()
			.hasMessage(message);
	}
	
	@CsvSource({
		",firstName must not be null",
		"'  ',firstName must not be blank",
		"FirstNameFirstName,firstName must be at least 1 and no greater than 10 characters in length"
	})
	@ParameterizedTest
	void testSettingFirstName(String firstName, String message) throws Exception {
		Contact contact = new Contact("1", "First", "Last", "5553334444", "1234 Loblolly Lane");
		assertThatThrownBy(() -> contact.setFirstName(firstName))
			.isNotNull()
			.hasMessage(message);
	}
	
}
